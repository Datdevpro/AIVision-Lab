Office & Fruit: 12 classes, 200 photographs per class.
SPLITS.csv: stratified 80/20 train/validation, seed 42; matches the application's default split.
Extract all files into backend/data/sample_datasets/office-fruit on a matching source version to use offline.
See DATASET-LICENSE.txt for authors, original URLs, licenses and modifications.
